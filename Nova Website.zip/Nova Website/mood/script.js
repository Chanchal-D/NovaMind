function p1() {
    // Show the modal and overlay
    document.getElementById('modalA').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
  }

  function p2() {
    // Show the modal and overlay
    document.getElementById('modalB').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
  }

  function p3() {
    // Show the modal and overlay
    document.getElementById('modalC').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
  }

  function p4() {
    // Show the modal and overlay
    document.getElementById('modalD').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
  }

  function p5() {
    // Show the modal and overlay
    document.getElementById('modalE').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
  }

  function c1() {
    // Hide the modal and overlay
    document.getElementById('modalA').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
  }

  function c2() {
    // Hide the modal and overlay
    document.getElementById('modalB').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
  }

  function c3() {
    // Hide the modal and overlay
    document.getElementById('modalC').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
  }

  function c4() {
    // Hide the modal and overlay
    document.getElementById('modalD').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
  }

  function c5() {
    // Hide the modal and overlay
    document.getElementById('modalE').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
  }

  function select() {
    // Add logic to handle the selected mood and perform any necessary actions.
    alert("Mood selected! You can add your logic here to handle the selected mood.");
  }